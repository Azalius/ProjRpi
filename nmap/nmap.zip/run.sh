py ./main.py
exit $?