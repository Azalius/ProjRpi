apt update
apt install python3 --assume-yes
apt install nmap --assume-yes
python3 -m pip install mysql-connector-python 
chmod +x run.sh